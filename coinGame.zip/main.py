import turtle
import math
import random

#setting background
screen = turtle.Screen()
screen.setup(500,500)
# set the screen background
screen.bgpic("sky.jpg")
# making characters
player = turtle.Turtle()
benefit = turtle.Turtle()
harm = turtle.Turtle()
score = turtle.Turtle()
screen.tracer(12,25)

player.penup()
benefit.penup()
harm.penup()
score.penup()



#setting player
player.setheading(90)
screen.addshape("money.png")
player.shape("money.png")
player.sety(-210)
player.setheading(90)

screen.addshape("coin_2222.png")
benefit.shape("coin_2222.png")
benefit.goto(-100,500)
screen.addshape("bomb2.png")
harm.shape("bomb2.png")
harm.goto(0,300)
score.ht()

def start():
  score.goto(-205,0)
  score.write("Press Space To Start", font = ("Ariel" ,30))
  screen.update()

def colliding (one,two):
  dx = (one.xcor() - two.xcor())
  dy = (one.ycor() - two.ycor())
  dis = math.sqrt(dx * dx + dy * dy)
  if (dis < 60):
   return True
  else:
   return False
  
def left():#move player left
  player.setx(player.xcor()-5)

def right():#move player right
  player.setx(player.xcor()+5)

def game():
  life = 1
  points = 0
  score.goto(-210,210)
  while (life != 0):
    score.clear()
    if (player.xcor()>=220):#bounding the player in the 500x500 box
      player.goto(210,-210)
    # player.shape("money.png")
    elif (player.xcor()<=-220):
      player.goto(-210,-210)
      # player.shape("money.png")
    # else:
      # player.shape("money.png")

    if (harm.ycor() <= -300):
      harm.goto(random.randrange(-210,210),290)
    elif (colliding(player,harm)):
      harm.goto(random.randrange(-210,210),290)
      life = life - 1
    else:
      harm.sety(harm.ycor()-2)          

    if (benefit.ycor() <= -300):
      benefit.goto(random.randrange(-210,210),290)
    elif (colliding(player,benefit)):
      benefit.goto(random.randrange(-210,210),290)
      points = points + 100
    else:
      benefit.sety(benefit.ycor()-3)
      
    score.write('Lives= ' +str(life) + ' Money = $' +str(points), font= ("Ariel", 15))
    screen.update()
  if (life == 0):
   player.ht()
   benefit.ht()
   harm.ht( )
   score.clear()
   score.goto(-190,0)
   score.write("GAME OVER", font = ("Ariel", 50))
   score.goto(-90,-50)
   score.write('Your Score Was ' + str(points), font=("Ariel", 15))
   screen.update()


start()
screen.onkey(left, 'left')
screen.onkey(right, 'right')
screen.onkey(game, 'space')
screen.listen()
